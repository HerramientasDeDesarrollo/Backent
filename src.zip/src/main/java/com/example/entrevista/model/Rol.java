package com.example.entrevista.model;

public enum Rol {
    ADMIN, EMPRESA, USUARIO
}
