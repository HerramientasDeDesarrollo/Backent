package com.example.entrevista.model;

public enum EstadoPostulacion {
    PENDIENTE,
    EN_EVALUACION,
    COMPLETADA
}